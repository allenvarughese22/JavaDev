package io.javabrains.coronovirustracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoronovirusTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
