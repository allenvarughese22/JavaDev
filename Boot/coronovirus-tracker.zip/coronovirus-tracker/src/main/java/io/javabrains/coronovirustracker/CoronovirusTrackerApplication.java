package io.javabrains.coronovirustracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoronovirusTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoronovirusTrackerApplication.class, args);
	}

}
