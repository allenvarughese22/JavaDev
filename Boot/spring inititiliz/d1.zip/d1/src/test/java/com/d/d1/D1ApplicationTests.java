package com.d.d1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class D1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
